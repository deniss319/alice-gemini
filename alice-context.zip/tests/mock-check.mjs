import http from "node:http";

// Мок Gemini API: проверяем, что обработчик реально формирует правильный запрос
// и корректно разбирает ответ, не тратя настоящую квоту.
const PORT = 8799;
let lastRequest = null;
let mode = "ok"; // ok | quota | empty | model404

const server = http.createServer((req, res) => {
  let body = "";
  req.on("data", c => (body += c));
  req.on("end", () => {
    const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
    if (url.pathname === "/__last") {
      res.writeHead(200, { "content-type": "application/json" });
      return res.end(JSON.stringify(lastRequest));
    }
    if (url.pathname === "/__mode") {
      mode = url.searchParams.get("m") || "ok";
      res.writeHead(200);
      return res.end("ok");
    }
    lastRequest = { path: url.pathname, method: req.method, body: body ? JSON.parse(body) : null, key: req.headers["x-goog-api-key"] };

    res.setHeader("content-type", "application/json");
    if (url.pathname.endsWith("/models") || url.pathname === "/models") {
      res.writeHead(200);
      return res.end(JSON.stringify({ models: [
        { name: "models/gemini-2.5-flash", supportedGenerationMethods: ["generateContent"] },
        { name: "models/gemini-2.5-flash-lite", supportedGenerationMethods: ["generateContent"] },
        { name: "models/text-embedding-004", supportedGenerationMethods: ["embedContent"] }
      ] }));
    }
    if (mode === "quota") {
      res.writeHead(429);
      return res.end(JSON.stringify({ error: { code: 429, message: "Resource has been exhausted", details: [{ retryDelay: "37s" }] } }));
    }
    if (mode === "empty") {
      res.writeHead(200);
      return res.end(JSON.stringify({ candidates: [{ finishReason: "SAFETY", content: {} }] }));
    }
    if (mode === "model404") {
      res.writeHead(404);
      return res.end(JSON.stringify({ error: { code: 404, message: "models/gemini-x is not found for API version v1beta" } }));
    }
    res.writeHead(200);
    res.end(JSON.stringify({
      candidates: [{ finishReason: "STOP", content: { parts: [{ text: "Космос — это бесконечное пространство со звёздами и планетами." }] } }]
    }));
  });
});

server.listen(PORT, "127.0.0.1", async () => {
  const { default: handler } = await import(`file://${process.cwd()}/api/index.js`);
  process.env.GEMINI_API_KEY = "test-key";
  // перенаправляем запросы мока через глобальный fetch
  const realFetch = globalThis.fetch;
  globalThis.fetch = (url, opts) => realFetch(String(url).replace("https://generativelanguage.googleapis.com", `http://127.0.0.1:${PORT}`), opts);

  const call = async (command, history = []) => {
    let out;
    const res = { status() { return this; }, json(v) { out = v; return v; }, setHeader() {} };
    await handler({ method: "POST", body: { request: { command, original_utterance: command }, state: { session: { history } } } }, res);
    return out;
  };

  const results = [];
  const check = (name, ok, extra = "") => results.push(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  " + extra : ""}`);

  // 1. обычный вопрос
  let r = await call("расскажи про космос");
  check("обычный ответ приходит от модели", r.response.text.includes("Космос"), r.response.text);
  const last = await realFetch(`http://127.0.0.1:${PORT}/__last`).then(x => x.json());
  check("ключ передан заголовком x-goog-api-key", last.key === "test-key");
  check("модель выбрана из опубликованного списка", /models\/gemini-2\.5-flash/.test(last.path), last.path);
  check("systemInstruction на месте", !!last.body.systemInstruction?.parts?.[0]?.text);
  check("maxOutputTokens ограничен", last.body.generationConfig.maxOutputTokens <= 220);
  check("tools не включены без GEMINI_SEARCH", !last.body.tools);

  // 2. история передаётся в модель
  r = await call("а что такое звёзды?", [
    { role: "user", text: "привет" },
    { role: "model", text: "привет, чем помочь?" }
  ]);
  const last2 = await realFetch(`http://127.0.0.1:${PORT}/__last`).then(x => x.json());
  check("история уходит в contents", last2.body.contents.length === 3, `contents=${last2.body.contents.length}`);
  check("роли сохраняются", last2.body.contents[1].role === "model");

  // 3. поиск включается переменной окружения
  process.env.GEMINI_SEARCH = "on";
  r = await call("какая сегодня погода в Москве");
  const last3 = await realFetch(`http://127.0.0.1:${PORT}/__last`).then(x => x.json());
  check("grounding включён для поискового запроса", JSON.stringify(last3.body.tools || []).includes("google_search"), JSON.stringify(last3.body.tools));
  r = await call("расскажи сказку");
  const last4 = await realFetch(`http://127.0.0.1:${PORT}/__last`).then(x => x.json());
  check("без поискового интента grounding не включается", !last4.body.tools);
  delete process.env.GEMINI_SEARCH;

  // 4. ошибки
  await realFetch(`http://127.0.0.1:${PORT}/__mode?m=quota`);
  r = await call("что нового");
  check("429 -> понятная фраза с задержкой", /лимит/i.test(r.response.text), r.response.text);
  await realFetch(`http://127.0.0.1:${PORT}/__mode?m=empty`);
  r = await call("что нового");
  check("пустой/заблокированный ответ -> отказ без падения", /обработать/i.test(r.response.text), r.response.text);
  await realFetch(`http://127.0.0.1:${PORT}/__mode?m=ok`);

  console.log(results.join("\n"));
  const failed = results.filter(x => x.startsWith("FAIL")).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  server.close();
  process.exit(failed ? 1 : 0);
});
