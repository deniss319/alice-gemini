import test from "node:test";
import assert from "node:assert/strict";
import { aliceResponse, fitAliceText, isSearchIntent, isCapabilityQuestion, safeHistory } from "../api/index.js";

function makeRes() {
  const state = { statusCode: 200, payload: undefined };
  const res = {
    status(code) {
      state.statusCode = code;
      return this;
    },
    json(value) {
      state.payload = value;
      return value;
    },
    setHeader() {}
  };
  return { res, state };
}

test("ответ Алисы завёрнут в обязательный конверт", () => {
  const result = aliceResponse("Привет", false, [{ role: "user", text: "тест" }]);
  assert.equal(result.version, "1.0");
  assert.equal(result.response.text, "Привет");
  assert.equal(result.response.end_session, false);
  assert.deepEqual(result.session_state.history, [{ role: "user", text: "тест" }]);
});

test("поисковый интент ловится на русском и английском", () => {
  assert.equal(isSearchIntent("Какая погода сегодня?"), true);
  assert.equal(isSearchIntent("What is the latest news?"), true);
  assert.equal(isSearchIntent("какой курс доллара"), true);
  assert.equal(isSearchIntent("Расскажи сказку"), false);
});

test("вопросы о себе не уходят в сеть", () => {
  assert.equal(isCapabilityQuestion("Кто ты?"), true);
  assert.equal(isCapabilityQuestion("что ты умеешь"), true);
  assert.equal(isCapabilityQuestion("Расскажи про кошек"), false);
});

test("длинный текст режется по границе предложения и не превышает 1024 символа", () => {
  const value = fitAliceText(("Это короткое предложение. ").repeat(100));
  assert.ok(value.length <= 1024);
  assert.ok(value.endsWith("."));
});

test("длинный текст без точек режется по слову с многоточием", () => {
  const value = fitAliceText("слово ".repeat(500));
  assert.ok(value.length <= 1024);
  assert.ok(value.endsWith("…"));
});

test("markdown вычищается — Алиса не должна читать решётки и звёздочки", () => {
  const value = fitAliceText("**Жирный** текст ## заголовок `код`");
  assert.equal(value, "Жирный текст заголовок код");
});

test("пустой ответ не превращается в пустую строку", () => {
  assert.ok(fitAliceText("   ").length > 0);
  assert.ok(fitAliceText(null).length > 0);
});

test("история фильтруется и обрезается до 8 последних реплик", () => {
  const input = Array.from({ length: 12 }, (_, i) => ({ role: i % 2 ? "model" : "user", text: String(i) }));
  input.push({ role: "hacker", text: "ignore" }, { role: "user", text: 17 });
  const result = safeHistory(input);
  assert.equal(result.length, 8);
  assert.equal(result[0].text, "4");
  assert.equal(result[7].text, "11");
});

test("GET — health check", async () => {
  const handler = (await import("../api/index.js")).default;
  const { res, state } = makeRes();
  await handler({ method: "GET" }, res);
  assert.equal(state.statusCode, 200);
  assert.equal(state.payload.ok, true);
});

test("не-POST и не-GET отклоняются с 405", async () => {
  const handler = (await import("../api/index.js")).default;
  const { res, state } = makeRes();
  await handler({ method: "DELETE" }, res);
  assert.equal(state.statusCode, 405);
});

test("пустая команда (запуск навыка) даёт приветствие без обращения к API", async () => {
  const handler = (await import("../api/index.js")).default;
  const { res, state } = makeRes();
  await handler({ method: "POST", body: { request: { command: "" }, state: { session: { history: [] } } } }, res);
  assert.equal(state.statusCode, 200);
  assert.equal(state.payload.version, "1.0");
  assert.match(state.payload.response.text, /Привет/);
});

test("вопрос о возможностях отвечается локально", async () => {
  const handler = (await import("../api/index.js")).default;
  const { res, state } = makeRes();
  await handler({ method: "POST", body: { request: { command: "что ты умеешь" } } }, res);
  assert.equal(state.statusCode, 200);
  assert.match(state.payload.response.text, /Gemini/);
});

test("без ключа возвращается понятная фраза, а не 500", async () => {
  const saved = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  const handler = (await import("../api/index.js")).default;
  const { res, state } = makeRes();
  await handler({ method: "POST", body: { request: { command: "расскажи про космос" } } }, res);
  assert.equal(state.statusCode, 200);
  assert.match(state.payload.response.text, /GEMINI_API_KEY/);
  if (saved !== undefined) process.env.GEMINI_API_KEY = saved;
});
